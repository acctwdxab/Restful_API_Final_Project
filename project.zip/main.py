from google.cloud import datastore
from flask import Flask, redirect, render_template, session, url_for
from six.moves.urllib.parse import urlencode
import json
from authlib.integrations.flask_client import OAuth
import loads
import boats
import constants


app = Flask(__name__)
app.config['SECRET_KEY'] = 'secretkeyyy'
# app.config['SESSION_COOKIE_DOMAIN'] = 'False'
app.register_blueprint(loads.bp)
app.register_blueprint(boats.bp)
client = datastore.Client()
USERS = 'USERS'
BOATS = 'BOATS'
LOADS = 'LOADS'

oauth = OAuth(app)
auth0 = oauth.register(
    'auth0',
    client_id=constants.CLIENT_ID,
    client_secret=constants.CLIENT_SECRET,
    api_base_url="https://" + constants.DOMAIN,
    access_token_url="https://" + constants.DOMAIN + "/oauth/token",
    authorize_url="https://" + constants.DOMAIN + "/authorize",
    client_kwargs={
        'scope': 'openid profile email',
    },
    jwks_uri="https://final-portfolio-wudan.us.auth0.com/.well-known/jwks.json"
)


@app.route('/')
def index():
    return render_template("home.html")



#https://auth0.com/docs/quickstart/webapp/python/01-login
@app.route('/callback')
def callback_handling():
    user_flag = False
    id_token = auth0.authorize_access_token()["id_token"]
    print(id_token)
    resp = auth0.get('userinfo')
    userinfo = resp.json()
    print(userinfo)

    query = client.query(kind=USERS)
    results = list(query.fetch())
    for r in results:
        if r["user_id"] == userinfo["sub"]:
            user_flag = True
    if not user_flag:
        new_user = datastore.entity.Entity(key=client.key(USERS))
        new_user.update({"user_id": userinfo["sub"], "name": userinfo["nickname"]})
        client.put(new_user)


    session['jwt_payload'] = userinfo
    session['profile'] = {
        'user_id': userinfo['sub'],
        'name': userinfo['nickname'],
        'email': userinfo['email'],
    }
    session['token'] = id_token
    return redirect('/welcome')


@app.route('/ui_login')
def login():
    return auth0.authorize_redirect(redirect_uri=constants.CALLBACK_URL)


@app.route('/welcome')
def welcome():
    return render_template('userinfo.html',
                           userinfo=session.get('profile'),
                           userinfo_all=session.get('jwt_payload'),
                           token=session.get('token'))


@app.route('/logout')
def logout():
    session.clear()
    params = {'returnTo': url_for('welcome', _external=True), 'client_id': constants.CLIENT_ID}
    return redirect(auth0.api_base_url + '/v2/logout?' + urlencode(params))


@app.route('/users', methods=['GET'])
def users_get():
    query = client.query(kind=USERS)
    results = list(query.fetch())
    return json.dumps(results), 200


if __name__ == '__main__':
    app.run(host='localhost', port=8080, debug=True)
