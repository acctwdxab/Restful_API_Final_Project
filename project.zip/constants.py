# constants for verification
# auth0 app information
CLIENT_ID = 'eETlB3B4GVdMKOFIa3Kwj6H0LfQM0HVi'
CLIENT_SECRET = 'kFvIpVy7zg25BuHz22hAG_nsgDrGu2zO9iJyR6j94gEWY73oTR26DVowvdcLxTTo'
DOMAIN = 'final-portfolio-wudan.us.auth0.com'
# CALLBACK_URL = 'http://localhost:8080/callback'
CALLBACK_URL = 'https://final-wudan.wl.r.appspot.com/callback'
ALGORITHMS = ["RS256"]
