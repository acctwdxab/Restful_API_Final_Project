from flask import Blueprint, request, jsonify
from google.cloud import datastore
import authorization

client = datastore.Client()

bp = Blueprint('boats', __name__, url_prefix='/boats')
BOATS = "boats"
LOADS = "loads"

# create a boat
@bp.route('', methods=['POST'])
def boats_post():
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406
    # if missing/invalid JWT return 401
    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    owner_id = payload["sub"]


    content = request.get_json()
    if len(content) != 3:
        return jsonify(Error="The request object is missing at least one of the required attributes"), 400

    new_load = datastore.entity.Entity(key=client.key(BOATS))
    new_load.update({"maintained": content["maintained"],
                   "date_of_manufacture": content["date_of_manufacture"], "city_origin": content["city_origin"],
                   "owner_id": owner_id})
    client.put(new_load)
    result = client.get(new_load.key)
    result["id"] = new_load.key.id
    result["self"] = request.url_root + 'boats/' + str(new_load.key.id)
    return jsonify(result), 201




@bp.route('', methods=['GET'])
def boats_get():
    if (request.headers['Accept'] != 'application/json'):
        if (request.headers['Accept'] != '*/*'):
            return jsonify(Error="Accept needs to be JSON."), 406

    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    query = client.query(kind=BOATS)
    # NEED TO TEST THIS FILTER
    query.add_filter("owner_id", "=", payload["sub"])
    boat_total = len(list(query.fetch()))
    q_limit = int(request.args.get('limit', '5'))
    q_offset = int(request.args.get('offset', '0'))
    l_iterator = query.fetch(limit=q_limit, offset=q_offset)
    pages = l_iterator.pages
    results = list(next(pages))
    if l_iterator.next_page_token:
        next_offset = q_offset + q_limit
        next_url = request.base_url + "?limit=" + str(q_limit) + "&offset=" + str(next_offset)
    else:
        next_url = None
    for e in results:
        e["id"] = e.key.id
        e["self"] = request.url_root + 'boats/' + str(e.key.id)
        e["total_boats"] = boat_total
    output = {"boats": results}
    if next_url:
        output["next"] = next_url
    return jsonify(output), 200


@bp.route('', methods=['PUT', 'DELETE'])
def boats_invalid():
    return jsonify(Error="These operations are not allowed on the entire list."), 405



@bp.route('/<id>', methods=['GET'])
def boats_get_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406

    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    boat_key = client.key(BOATS, int(id))
    boat = client.get(key=boat_key)
    if not boat:
        return jsonify(Error="No boat with this boat_id exists"), 404
    if boat["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    boat["id"] = boat.key.id
    boat["self"] = request.url_root + 'boats/' + str(boat.key.id)
    return jsonify(boat), 200


@bp.route('/<id>', methods=['PATCH'])
def boats_patch_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406

    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    content = request.get_json()
    boat_key = client.key(BOATS, int(id))
    boat = client.get(key=boat_key)
    if not boat:
        return jsonify(Error="No boat with this boat_id exists"), 404
    if boat["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    for key in content:
        if boat[key]:
            boat[key] = content[key]
            client.put(boat)
    boat["id"] = boat.key.id
    boat["self"] = request.url_root + 'boats/' + str(boat.key.id)
    return jsonify(boat), 200


@bp.route('/<id>', methods=['PUT'])
def boats_put_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406

    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401

    content = request.get_json()
    if len(content) != 3:
        return jsonify(Error="The request object is missing at least one of the required attributes"), 400
    boat_key = client.key(BOATS, int(id))
    boat = client.get(key=boat_key)
    if not boat:
        return jsonify(Error="No boat with this boat_id exists"), 404
    if boat["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    owner_id = payload["sub"]

    boat.update({"maintained": content["maintained"],
                   "date_of_manufacture": content["date_of_manufacture"], "city_origin": content["city_origin"],
                   "owner_id": owner_id})
    client.put(boat)
    result = client.get(boat.key)
    result["id"] = boat.key.id
    result["self"] = request.url_root + 'boats/' + str(boat.key.id)
    return jsonify(result), 200




@bp.route('/<id>', methods=['DELETE'])
def boats_delete_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406

    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    boat_key = client.key(BOATS, int(id))
    boat = client.get(key=boat_key)
    if not boat:
        return jsonify(Error="No boat with this boat_id exists"), 404
    if boat["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403

    if 'loads' in boat.keys() and boat['loads']:
        for i in range(len(boat['loads'])):
            load_key = client.key(LOADS, boat['loads'][i]['id'])
            load = client.get(key=load_key)

            i = 0
            length = len(load['boats'])
            while i < length:
                if boat.key.id == load['boats'][i]['id']:
                    load['boats'].pop(i)
                    length = len(load['boats'])
                    client.put(load)
                else:
                    i += 1
    client.delete(boat_key)
    return jsonify(''), 204



@bp.route('/<oid>/loads/<iid>', methods=['PUT'])
def put_loads_on_boat(oid, iid):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406
        # if missing/invalid JWT return 401
    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    boat_key = client.key(BOATS, int(oid))
    boat = client.get(key=boat_key)
    load_key = client.key(LOADS, int(iid))
    load = client.get(key=load_key)
    if not load or not boat:
        return jsonify(Error="No boat and/or load exists with this id."), 404
    if boat["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    # check if load is already assigned to this boat
    if 'loads' in boat.keys():
        for i in range(len(boat['loads'])):
            if load.key.id == boat['loads'][i]['id']:
                return jsonify(Error="This load is already on this boat."), 403

    if 'loads' in boat.keys():
        boat['loads'].append({"id": load.key.id, "self": request.url_root + 'loads/' + str(load.key.id)})
    else:
        boat['loads'] = [{"id": load.key.id, "self": request.url_root + 'loads/' + str(load.key.id)}]
    client.put(boat)
    load['boats'] = {"id": boat.key.id, "self": request.url_root + 'boats/' + str(boat.key.id)}
    client.put(load)
    return jsonify(''), 204


@bp.route('/<oid>/loads/<iid>', methods=['DELETE'])
def delete_loads_on_boat(oid, iid):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406

    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    boat_key = client.key(BOATS, int(oid))
    boat = client.get(key=boat_key)
    load_key = client.key(LOADS, int(iid))
    load = client.get(key=load_key)
    if not load or not boat:
        return jsonify(Error="No boat and/or load exists with this id."), 404
    if boat["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403

    if 'loads' in boat.keys() and boat['loads']:
        i = 0
        length = len(boat['loads'])
        while i < length:
            if load.key.id == boat['loads'][i]['id']:
                boat['loads'].pop(i)
                length = len(boat['loads'])
                client.put(boat)
                load['boats'] = None
                client.put(load)
                return '', 204
            else:
                i += 1
    return jsonify(Error="The load is not on this boat."), 404



@bp.route('/<id>/loads', methods=['GET'])
def loads_get_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406

    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    boat_key = client.key(BOATS, int(id))
    boat = client.get(key=boat_key)
    if not boat:
        return jsonify(Error="No boat exists with this id."), 404
    if boat["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    load_list = []
    if 'loads' in boat.keys() and boat['loads']:
        for i in range(len(boat['loads'])):
            load_key = client.key(LOADS, boat['loads'][i]['id'])
            load = client.get(key=load_key)
            load["id"] = load.key.id
            load["self"] = request.url_root + 'loads/' + str(load.key.id)
            load_list.append(load_key)
            client.put(load)
        return jsonify(client.get_multi(load_list)), 200
    else:
        return jsonify([]), 204
