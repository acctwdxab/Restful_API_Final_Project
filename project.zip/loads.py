from flask import Blueprint, request, jsonify
from google.cloud import datastore
import authorization

client = datastore.Client()

bp = Blueprint('loads', __name__, url_prefix='/loads')
LOADS = "loads"
BOATS = "boats"


@bp.route('', methods=['POST'])
def loads_post():
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406
    if 'Authorization' not in request.headers:
        return jsonify({"Error": "Missing auth credentials."}), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    owner_id = payload["sub"]
    content = request.get_json()
    # When missing attributes
    if len(content) != 3:
        return jsonify(Error="The request object is missing at least one of the required attributes"), 400
    new_load = datastore.entity.Entity(key=client.key(LOADS))
    new_load.update({"name": content["name"], "weight": content["weight"],
                   "description": content["description"], "owner_id": owner_id})
    client.put(new_load)
    result = client.get(new_load.key)
    result["id"] = new_load.key.id
    result["self"] = request.url_root + 'loads/' + str(new_load.key.id)
    return jsonify(result), 201



@bp.route('', methods=['GET'])
def loads_get():
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406
    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify({"Error": "Unauthorized."}), 401
    query = client.query(kind=LOADS)
    query.add_filter("owner_id", "=", payload["sub"])
    load_total = len(list(query.fetch()))
    q_limit = int(request.args.get('limit', '5'))
    q_offset = int(request.args.get('offset', '0'))
    g_iterator = query.fetch(limit=q_limit, offset=q_offset)
    pages = g_iterator.pages
    results = list(next(pages))
    if g_iterator.next_page_token:
        next_offset = q_offset + q_limit
        next_url = request.base_url + "?limit=" + str(q_limit) + "&offset=" + str(next_offset)
    else:
        next_url = None
    for e in results:
        e["id"] = e.key.id
        e["self"] = request.url_root + 'loads/' + str(e.key.id)
        e["total_loads"] = load_total
    output = {"loads": results}
    if next_url:
        output["next"] = next_url
    return jsonify(output), 200


@bp.route('', methods=['PUT', 'DELETE'])
def loads_invalid():
    return jsonify(Error="These operations are not allowed on the entire list."), 405



@bp.route('/<id>', methods=['GET'])
def loads_get_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406
    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    load_key = client.key(LOADS, int(id))
    load = client.get(key=load_key)
    if not load:
        return jsonify(Error="No load with this load_id exists"), 404
    if load["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    load["id"] = load.key.id
    load["self"] = request.url_root + 'loads/' + str(load.key.id)
    return jsonify(load)


@bp.route('/<id>', methods=['PATCH'])
def loads_patch_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406
    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    content = request.get_json()
    load_key = client.key(LOADS, int(id))
    load = client.get(key=load_key)
    if not load:
        return jsonify(Error="No load with this load_id exists"), 404
    if load["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    for key in content:
        if load[key]:
            load[key] = content[key]
            client.put(load)
    load["id"] = load.key.id
    load["self"] = request.url_root + 'loads/' + str(load.key.id)
    return jsonify(load), 200


@bp.route('/<id>', methods=['PUT'])
def loads_put_specific(id):
    if request.headers['Accept'] != 'application/json':
        if request.headers['Accept'] != '*/*':
            return jsonify(Error="Accept needs to be JSON."), 406
    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    content = request.get_json()
    # When missing attributes
    if len(content) != 3:
        return jsonify(Error="The request object is missing at least one of the required attributes"), 400
    load_key = client.key(LOADS, int(id))
    load = client.get(key=load_key)
    if not load:
        return jsonify(Error="No load with this load_id exists"), 404
    if load["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    owner_id = payload["sub"]
    load.update({"name": content["name"], "weight": content["weight"],
                     "description": content["description"], "owner_id": owner_id})
    client.put(load)
    result = client.get(load.key)
    result["id"] = load.key.id
    result["self"] = request.url_root + 'loads/' + str(load.key.id)
    return jsonify(result), 200



@bp.route('/<id>', methods=['DELETE'])
def loads_delete_specific(id):
    if request.headers['Accept'] != 'application/json':
        if (request.headers['Accept'] != '*/*'):
            return jsonify(Error="Accept needs to be JSON."), 406
    if 'Authorization' not in request.headers:
        return jsonify(Error="Missing auth credentials."), 401
    payload = authorization.verify_jwt(request)
    if not payload:
        return jsonify(Error="Unauthorized."), 401
    load_key = client.key(LOADS, int(id))
    load = client.get(key=load_key)
    if not load:
        return jsonify(Error="No load with this load_id exists"), 404
    if load["owner_id"] != payload["sub"]:
        return jsonify(Error="You are unauthorized to view this."), 403
    # check if load is on a boat and remove it
    if 'boats' in load.keys() and load['boats']:
        boat_key = client.key(BOATS, load['boats']['id'])
        boat = client.get(key=boat_key)
        if 'loads' in boat.keys() and boat['loads']:
            i = 0
            length = len(boat['loads'])
            while i < length:
                if load.key.id == boat['loads'][i]['id']:
                    boat['loads'].pop(i)
                    length = len(boat['loads'])
                    client.put(boat)
                else:
                    i += 1
    client.delete(load_key)
    return jsonify(''), 204
